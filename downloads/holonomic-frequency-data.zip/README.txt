HOLONOMIC OSCILLATOR FREQUENCY COMPARISON

Four newly integrated exact-position illustrations: omega = 100, 80, 60, 40 rad/s.
The omega=100 run matches the default first interactive holonomic layout.
Only omega varies. a=0.16, k=1.4, delta=0.15, initial q=2, oscillator phase
1.6209605332366719 rad, start (1.8,-0.9), source (-1.8,0.9), obstacle (0,0).
The holonomic robot body has fixed orientation. These are not learned-perception
experimental records. No position is rescaled, smoothed or snapped to the source.

All five MP4s are 72 seconds, 1920x1080, 30 fps. They share 0.125x model-time
playback, an initial 1.5-second hold, a model horizon of 8.5 seconds, and a final
2.5-second hold. Each robot stops on first entry into the radius-0.35 source
neighborhood. Current q=2 throughout these selected runs; the separate two-route
hybrid animation on the website demonstrates actual switching.

The full views share bounds [-5.5,5.5] on both axes. Recent-two-cycle close-ups
use equal x/y scale and label their local view width; only those insets magnify.

CSV columns are model_time_s,x,y,q,distance_to_source. JSON includes fixed
parameters, full precision samples, jump arrays and step-halving verification.
To regenerate samples with Node.js: node scripts/generate_holonomic_frequencies.mjs
The exact controller source and generation script are included at their original
relative paths. The controller SHA-256 in runs.json identifies the implementation.
