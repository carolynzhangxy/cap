import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {simulate,configuration,potentials} from '../dist/static/js/scene-controller.js';

// Match the first interactive holonomic scene. Freeze the phase and all gains
// from its default configuration; only omega changes between these four runs.
const layout={model:'holonomic',vehicle:[1.8,-.9],source:[-1.8,.9],obstacle:[0,0]};
const base=configuration(layout),runs=[];
for(const omega of [100,80,60,40]){
  const settings={omega,phase:base.phase,a:base.a,k:base.k,initialMode:2,recordJumpSamples:true};
  const run=simulate(layout,settings),fine=simulate(layout,{...settings,step:base.step/2});
  assert.equal(run.reason,'arrived');assert.ok(run.minClearance>0);
  const rows=[];for(let i=0;i<run.points.length;i+=5)rows.push(Array.from(run.points.slice(i,i+5)));
  const fineRows=[];for(let i=0;i<fine.points.length;i+=5)fineRows.push(Array.from(fine.points.slice(i,i+5)));
  let j=0,error=0,matched=0;
  for(const r of rows){while(j+1<fineRows.length&&fineRows[j+1][0]<=r[0]+1e-10)j++;
    if(Math.abs(fineRows[j][0]-r[0])<1e-10){error=Math.max(error,Math.hypot(r[1]-fineRows[j][1],r[2]-fineRows[j][2]));matched++;}}
  assert.ok(error<.002,`Step-halving discrepancy: ${error}`);
  assert.equal(run.events.length,fine.events.length);
  for(let i=0;i<run.events.length;i++)assert.ok(Math.abs(run.events[i].t-fine.events[i].t)<=base.step*2);
  for(const e of run.jumpStates){const values=potentials(...e.position,run.config);assert.equal(e.gapBefore,values[e.from-1]-Math.min(...values));assert.ok(e.gapBefore>=base.delta);assert.equal(values[e.to-1],Math.min(...values));}
  const bounds=[Math.min(...rows.map(r=>r[1])),Math.max(...rows.map(r=>r[1])),Math.min(...rows.map(r=>r[2])),Math.max(...rows.map(r=>r[2]))];
  assert.ok(bounds.every(x=>Math.abs(x)<5.15),'The common square view must contain every point.');
  runs.push({...run,points:undefined,rows,oscillatorCyclesPerSecond:omega/(2*Math.PI),frequencyReductionPercent:100-omega,
    verification:{stepHalvingMaxPositionError:error,matchedSamples:matched,arrivalTimeDifference:Math.abs(run.arrival-fine.arrival),bounds}});
}
const horizon=Math.ceil(Math.max(...runs.map(r=>r.duration))*2)/2;
const data={scope:'New exact-position numerical illustrations of the holonomic oscillatory law. Not learned-perception experimental records.',
  layout,columns:['model_time_s','x','y','q','distance_to_source'],
  video:{width:1920,height:1080,fps:30,intro:1.5,outro:2.5,speed:.125,horizon,duration:4+horizon/.125,
    viewBounds:[-5.5,5.5,-5.5,5.5],bodyOrientation:'Fixed; the holonomic plant has no heading state.',
    detail:'Recent two oscillator cycles; equal x/y scale. Local display range is shown.'},
  controllerSha256:crypto.createHash('sha256').update(fs.readFileSync(new URL('../dist/static/js/scene-controller.js',import.meta.url))).digest('hex'),runs};
const dir=new URL('../dist/data/holonomic-frequency-comparison/',import.meta.url);fs.mkdirSync(dir,{recursive:true});
fs.writeFileSync(new URL('runs.json',dir),JSON.stringify(data));
console.log(JSON.stringify({video:data.video,runs:runs.map(r=>({omega:r.config.omega,arrival:r.arrival,clearance:r.minClearance,events:r.events,verification:r.verification}))},null,2));
