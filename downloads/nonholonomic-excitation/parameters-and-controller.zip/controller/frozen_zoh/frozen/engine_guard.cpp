#include <cmath>
#include <algorithm>
#include <limits>

// Standalone numerical diagnostic. No fast-math, external models or GPU kernels.
constexpr double PI=3.1415926535897932384626433832795;
struct Params {
  double omega,gamma,kappa,dstar,rhoo,delta,hx,hy,targetx,targety;
  double horizon,step,save_step,L,T,wheel_radius,track,wheel_cap,acc_cap,wheel_tau;
  double initial_x,initial_y,heading0,phase_sign,control_step;
  double lambda_c,s1,s2,source_angle,hxy,physical_exclusion,cover,width;
  double cover_x,cover_y,obstacle_x,obstacle_y,field_offset,safe_radius,solver_tol;
  int initial_mode,switch_enabled,adaptive_check;
  int enforce_chart;
  int method;
  int geometry,plant; // geometry: flat0/obstacle1; plant: continuous0/average1/held2/wheels3
};
static const double* ref_data=nullptr;static int ref_rows=0;
extern "C" void set_reference(const double* data,int rows){ref_data=data;ref_rows=rows;}
struct XY { double x,y; };
struct State { double x,y,heading,wl=0,wr=0; };

static double barrier(double c,const Params& p) {
  if(c<=0) return std::numeric_limits<double>::quiet_NaN();
  if(c>=p.rhoo) return 0.;
  return (p.rhoo-c)*(p.rhoo-c)*std::log(p.rhoo/c);
}
// Environment-only scalar evaluator. Source coordinates never enter the mode term.
static double environment_loss(double x,double y,const Params& p) {
  double dx=x-p.targetx,dy=y-p.targety;
  return .5*(p.hx*dx*dx+2*p.hxy*dx*dy+p.hy*dy*dy)-p.field_offset;
}
static void localization(double s,const Params& p,double& chi,double& dc) {
  if(s<=p.s1){chi=1;dc=0;return;} if(s>=p.s2){chi=0;dc=0;return;}
  double t=(s-p.s1)/(p.s2-p.s1),k=1/t-1/(1-t);
  chi=k>=0?1/(1+std::exp(-k)):std::exp(k)/(1+std::exp(k));
  dc=chi*(1-chi)*(-1/(t*t)-1/((1-t)*(1-t)))/(p.s2-p.s1);
}
static double mode_term(double x,double y,int q,const Params& p) {
  if(p.method==2) return 0.;
  double r=std::hypot(x-p.obstacle_x,y-p.obstacle_y);
  if(p.method==1){double chi,dc;localization(r-p.dstar,p,chi,dc);int sign=q==1?1:-1;return p.lambda_c*chi*(1-sign*x/r);}
  double e=std::atan2(y-p.obstacle_y,x-p.obstacle_x)-p.source_angle,alpha=(1.5-q)*(1-std::cos(e));
  return 1-std::cos(e+alpha);
}

// Exact distance to the closed convex complementary wedge, or the separately
// labelled historical max-distance implementation. Neither uses source data.
static double cover_distance(double x,double y,int q,const Params& p,XY* grad=nullptr) {
  x-=p.cover_x;y-=p.cover_y;
  const double n=1/std::sqrt(2.),sign=q==1?-1.:1.;
  double u=(sign*x-y)*n-p.cover,v=(sign*x+y)*n-p.cover;
  if(p.method==4){if(grad)*grad=u>=v?XY{sign*n,-n}:XY{sign*n,n};return std::max(u,v);}
  double a=std::max(0.,u),b=std::max(0.,v),d=std::hypot(a,b);
  if(grad)*grad=d>0?XY{sign*n*(a+b)/d,n*(b-a)/d}:XY{NAN,NAN};return d;
}
static double cover_barrier(double d,const Params& p) {
  if(d<=0)return INFINITY;
  if(d>=p.width)return 0.;
  return (p.width-d)*(p.width-d)*std::log(p.width/d);
}

static double potential(double x,double y,int q,const Params& p) {
  double measured_minus_J=environment_loss(x,y,p);
  if(p.method>=3)return measured_minus_J+cover_barrier(cover_distance(x,y,q,p),p);
  if(!p.geometry)return measured_minus_J;
  if(p.method==0){double e=std::atan2(y-p.obstacle_y,x-p.obstacle_x)-p.source_angle,alpha=(1.5-q)*(1-std::cos(e));return measured_minus_J+barrier(std::hypot(x-p.obstacle_x,y-p.obstacle_y)-p.dstar,p)+1-std::cos(e+alpha);}
  return measured_minus_J+barrier(std::hypot(x-p.obstacle_x,y-p.obstacle_y)-p.dstar,p)+mode_term(x,y,q,p);
}
// Analytic field gradient is used ONLY by the offline averaged reference.
static XY gradient(double x,double y,int q,const Params& p) {
  XY g{p.hx*(x-p.targetx)+p.hxy*(y-p.targety),p.hxy*(x-p.targetx)+p.hy*(y-p.targety)};
  if(p.method>=3){XY gd;double d=cover_distance(x,y,q,p,&gd);if(d<=0)return {NAN,NAN};
    if(d<p.width){double h=p.width-d,bp=-2*h*std::log(p.width/d)-h*h/d;g.x+=bp*gd.x;g.y+=bp*gd.y;}return g;}
  if(!p.geometry)return g;
  double r=std::hypot(x-p.obstacle_x,y-p.obstacle_y),c=r-p.dstar,db=0,angular=0;
  if(c<=0)return {NAN,NAN};
  if(c<p.rhoo)db=-2*(p.rhoo-c)*std::log(p.rhoo/c)-(p.rhoo-c)*(p.rhoo-c)/c;
  if(p.method==0){double e=std::atan2(y-p.obstacle_y,x-p.obstacle_x)-p.source_angle,a=1.5-q;angular=std::sin(e+a*(1-std::cos(e)))*(1+a*std::sin(e));}
  if(p.method==1){double chi,dc;localization(c,p,chi,dc);int sign=q==1?1:-1;db+=p.lambda_c*dc*(1-sign*x/r);angular=sign*p.lambda_c*chi*y/r;}
  g.x+=db*(x-p.obstacle_x)/r-angular*(y-p.obstacle_y)/(r*r);g.y+=db*(y-p.obstacle_y)/r+angular*(x-p.obstacle_x)/(r*r);return g;
}
static double gap(const State& s,int q,const Params& p) {
  if(p.method>=3){double a=cover_barrier(cover_distance(s.x,s.y,q,p),p),b=cover_barrier(cover_distance(s.x,s.y,3-q,p),p);return a-std::min(a,b);}
  if(!p.geometry) return 0;
  if(p.method==2)return 0;
  if(p.method==1){double chi,dc;double r=std::hypot(s.x-p.obstacle_x,s.y-p.obstacle_y);localization(r-p.dstar,p,chi,dc);return std::max(0.,-2*(q==1?1:-1)*p.lambda_c*chi*s.x/r);}
  double v1=potential(s.x,s.y,1,p),v2=potential(s.x,s.y,2,p);
  return (q==1?v1:v2)-std::min(v1,v2);
}
static int best(const State& s,const Params& p) {
  if(p.method>=3)return cover_distance(s.x,s.y,1,p)>=cover_distance(s.x,s.y,2,p)?1:2;
  if(p.method!=0)return mode_term(s.x,s.y,1,p)<=mode_term(s.x,s.y,2,p)?1:2;
  return potential(s.x,s.y,1,p)<=potential(s.x,s.y,2,p)?1:2;
}
static double command(double t,double v,const Params& p) {
  // exp(-kappa*V*S)e1 dotted with eta = cos(2*pi*omega*t+kappa*V).
  return std::sqrt(4*PI*p.gamma*p.omega/p.kappa)*std::cos(2*PI*p.omega*t+p.phase_sign*p.kappa*v);
}
static XY flow(double t,double x,double y,int q,const Params& p) {
  if(p.plant==1||p.plant==4){XY g=gradient(x,y,q,p);return {-.5*p.gamma*g.x,-.5*p.gamma*g.y};}
  double V=potential(x,y,q,p);if(!std::isfinite(V))return {NAN,NAN};
  double v=command(t,V,p),angle=p.heading0+2*PI*std::sqrt(p.omega)*t;
  return {v*std::cos(angle),v*std::sin(angle)};
}
static XY manifold_flow(double rho,double theta,int q,const Params& p) {
  double s=std::exp(rho),r=p.dstar+s,nx=std::cos(theta),ny=std::sin(theta);XY g=gradient(p.obstacle_x+r*nx,p.obstacle_y+r*ny,q,p);
  return {-.5*p.gamma*(g.x*nx+g.y*ny)/s,-.5*p.gamma*(-g.x*ny+g.y*nx)/r};
}
static State rk4(double t,const State& s,double h,int q,const Params& p) {
  if(p.plant==4){double rho=std::log(std::hypot(s.x-p.obstacle_x,s.y-p.obstacle_y)-p.dstar),theta=std::atan2(s.y-p.obstacle_y,s.x-p.obstacle_x);
    XY a=manifold_flow(rho,theta,q,p),b=manifold_flow(rho+h*a.x/2,theta+h*a.y/2,q,p);
    XY c=manifold_flow(rho+h*b.x/2,theta+h*b.y/2,q,p),d=manifold_flow(rho+h*c.x,theta+h*c.y,q,p);
    double rr=p.dstar+std::exp(rho+h*(a.x+2*b.x+2*c.x+d.x)/6),tt=theta+h*(a.y+2*b.y+2*c.y+d.y)/6;
    State z=s;z.x=p.obstacle_x+rr*std::cos(tt);z.y=p.obstacle_y+rr*std::sin(tt);return z;}

  XY a=flow(t,s.x,s.y,q,p),b=flow(t+h/2,s.x+h*a.x/2,s.y+h*a.y/2,q,p);
  XY c=flow(t+h/2,s.x+h*b.x/2,s.y+h*b.y/2,q,p),d=flow(t+h,s.x+h*c.x,s.y+h*c.y,q,p);
  State r=s;r.x+=h*(a.x+2*b.x+2*c.x+d.x)/6;r.y+=h*(a.y+2*b.y+2*c.y+d.y)/6;
  if(p.plant==0)r.heading=p.heading0+2*PI*std::sqrt(p.omega)*(t+h);
  return r;
}
static bool valid(const State& s,const Params& p) {
  return std::isfinite(s.x)&&std::isfinite(s.y)&&(!p.enforce_chart||std::hypot(s.x-p.obstacle_x,s.y-p.obstacle_y)>p.dstar)&&(p.method<3||std::max(cover_distance(s.x,s.y,1,p),cover_distance(s.x,s.y,2,p))>0);
}
static State held(State s,double v,double w,double h) {
  double angle=w*h/2,si=std::abs(angle)<1e-10?1-angle*angle/6:std::sin(angle)/angle;
  s.x+=v*h*si*std::cos(s.heading+angle);s.y+=v*h*si*std::sin(s.heading+angle);s.heading+=w*h;return s;
}
extern "C" double evaluate_potential(const Params* p,double x,double y,int q){return potential(x,y,q,*p);}
extern "C" void evaluate_gradient(const Params* p,double x,double y,int q,double* out){XY g=gradient(x,y,q,*p);out[0]=g.x;out[1]=g.y;}
extern "C" double evaluate_command(const Params* p,double t,double v){return command(t,v,*p);}
extern "C" void integrate_held(double x,double y,double a,double v,double w,double h,double* out){State s{x,y,a};s=held(s,v,w,h);out[0]=s.x;out[1]=s.y;out[2]=s.heading;}

// Trace columns are declared once in runner.py. Events: time,x,y,q_before,q_after,gap_before,gap_after,V_drop.
constexpr int NC=18,NE=8;
extern "C" int simulate(const Params* cfg,double* trace,int capacity,double* detail,int detail_capacity,
                         double* events,int event_capacity,double* metrics) {
  const Params& p=*cfg;State s{p.initial_x,p.initial_y,p.heading0};int q=p.initial_mode?p.initial_mode:best(s,p);
  int rows=0,detail_rows=0,nev=0,reason=0,steps=0;double t=0;
  double rejected_x=NAN,rejected_y=NAN,rejected_time=NAN,adaptive_halvings=0;
  int initial_recoveries=0,ref_i=0;double err_integral=0,err_max=0,err_prev=0,err_tprev=0,err_duration=0;
  int control_stride=std::max(1,(int)std::llround(p.control_step/p.step));
  int save_stride=std::max(1,(int)std::llround(p.save_step/p.step));
  double u=0,turn=0,vactual=0,wactual=0,clipv=0,clipa=0,clipv_time=0,clipa_time=0;
  double minchart=1e100,minphysical=1e100,path=0,trackv=0,trackw=0,dwell=0,firstdwell=-1;
  double peakwheel=0,peakacc=0,peakjumpresid=0;
  auto jump=[&](double when,State& st)->bool {
    if(nev>=event_capacity)return false;
    int prev=q;double before=potential(st.x,st.y,q,p),g=gap(st,q,p);q=best(st,p);
    if(prev==q)return false;
    double* e=events+nev*NE;e[0]=when;e[1]=st.x;e[2]=st.y;e[3]=prev;e[4]=q;
    e[5]=g;e[6]=gap(st,q,p);e[7]=before-potential(st.x,st.y,q,p);
    if(!std::isfinite(before))initial_recoveries++;
    if(when>1e-12&&(p.plant!=2&&p.plant!=3)&&std::isfinite(g))peakjumpresid=std::max(peakjumpresid,std::abs(g-p.delta));
    nev++;return true;
  };
  auto save=[&](double* out){
    double V=potential(s.x,s.y,q,p),rr=std::hypot(s.x-p.obstacle_x,s.y-p.obstacle_y);
    out[0]=t;out[1]=s.x;out[2]=s.y;out[3]=s.heading;out[4]=q;out[5]=V;out[6]=gap(s,q,p);
    out[7]=p.geometry?rr-p.dstar:0.;out[8]=std::hypot(s.x-p.targetx,s.y-p.targety);
    out[9]=u;out[10]=turn;out[11]=vactual;out[12]=wactual;out[13]=s.wl;out[14]=s.wr;
    out[15]=clipv;out[16]=clipa;out[17]=dwell*p.T;
  };
  while(true){
    if(!std::isfinite(s.x)||!std::isfinite(s.y)){reason=1;break;}
    double rad=std::hypot(s.x-p.obstacle_x,s.y-p.obstacle_y);
    if(p.geometry&&rad*p.L<=p.physical_exclusion){reason=2;break;}
    if(p.geometry&&rad<=p.safe_radius){reason=8;break;}
    if(!valid(s,p)){reason=(p.method>=3&&std::max(cover_distance(s.x,s.y,1,p),cover_distance(s.x,s.y,2,p))<=0)?6:1;break;}
    if(!std::isfinite(potential(s.x,s.y,q,p))){
      if(p.switch_enabled&&std::isfinite(potential(s.x,s.y,3-q,p))){if(!jump(t,s)){reason=5;break;}}
      else{reason=6;break;}
    }
    double rr=std::hypot(s.x-p.obstacle_x,s.y-p.obstacle_y);
    if(ref_data&&ref_rows>1){
      while(ref_i+2<ref_rows&&ref_data[(ref_i+1)*3]<t)ref_i++;
      double ta=ref_data[ref_i*3],tb=ref_data[(ref_i+1)*3],mix=std::clamp((t-ta)/(tb-ta),0.,1.);
      double rx=ref_data[ref_i*3+1]*(1-mix)+ref_data[(ref_i+1)*3+1]*mix;
      double ry=ref_data[ref_i*3+2]*(1-mix)+ref_data[(ref_i+1)*3+2]*mix;
      double e2=(s.x-rx)*(s.x-rx)+(s.y-ry)*(s.y-ry);
      if(t>err_tprev){err_integral+=(t-err_tprev)*(e2+err_prev)/2;err_duration+=t-err_tprev;}
      err_prev=e2;err_tprev=t;err_max=std::max(err_max,std::sqrt(e2));
    }
    minchart=std::min(minchart,p.geometry?rr-p.dstar:1e100);
    minphysical=std::min(minphysical,p.geometry?rr*p.L-p.physical_exclusion:1e100);
    if(p.geometry&&rr*p.L<=p.physical_exclusion){reason=2;break;}
    if(rr>50){reason=3;break;}
    if((p.plant==2||p.plant==3)&&steps%control_stride==0){
      if(p.switch_enabled&&p.geometry&&gap(s,q,p)>=p.delta&&!jump(t,s)){reason=5;break;}
      u=command(t,potential(s.x,s.y,q,p),p);turn=2*PI*std::sqrt(p.omega);
    }else if((p.plant!=2&&p.plant!=3)){
      if(p.switch_enabled&&p.geometry&&gap(s,q,p)>=p.delta&&!jump(t,s)){reason=5;break;}
      u=(p.plant==1||p.plant==4)?0:command(t,potential(s.x,s.y,q,p),p);
      turn=(p.plant==1||p.plant==4)?0:2*PI*std::sqrt(p.omega);vactual=u;wactual=turn;
    }
    if(steps%save_stride==0||t>=p.horizon-1e-12){
      if(rows>=capacity){reason=4;break;}save(trace+rows*NC);rows++;
    }
    if((p.plant==2||p.plant==3)&&t*p.T<=10.+1e-9){
      if(detail_rows>=detail_capacity){reason=4;break;}save(detail+detail_rows*NC);detail_rows++;
    }
    if(t>=p.horizon-1e-12)break;
    double h=std::min(p.step,p.horizon-t);State before=s;
    if((p.plant!=2&&p.plant!=3)){
      double local=t,remaining=h;int internal=0;
      while(remaining>1e-13){
        double trial=remaining; State end=s,middle=s;
        for(int cuts=0;;cuts++){
          end=rk4(local,s,trial,q,p);middle=rk4(local,s,trial/2,q,p);
          bool ok=valid(end,p)&&valid(middle,p)&&std::isfinite(potential(end.x,end.y,q,p))&&std::isfinite(potential(middle.x,middle.y,q,p));
          bool near=p.method>=3&&cover_distance(s.x,s.y,q,p)<.08;
          if(ok&&p.adaptive_check&&near){
            State fine=rk4(local+trial/2,middle,trial/2,q,p);
            double error=std::hypot(fine.x-end.x,fine.y-end.y);
            ok=valid(fine,p)&&std::isfinite(error)&&error<=p.solver_tol*(1+std::hypot(s.x-p.obstacle_x,s.y-p.obstacle_y));
          }
          if(ok)break;
          rejected_x=end.x;rejected_y=end.y;rejected_time=local+trial;
          if(cuts>=35||trial<1e-12){reason=1;break;}
          trial/=2;adaptive_halvings++; if(adaptive_halvings>=100000000){reason=4;break;}
        }
        if(reason)break;
        if(p.switch_enabled&&p.geometry&&(gap(middle,q,p)>=p.delta||gap(end,q,p)>=p.delta)){
          double lo=0,hi=gap(middle,q,p)>=p.delta?trial/2:trial;
          for(int it=0;it<45&&hi-lo>1e-13;it++){
            double mid=(lo+hi)/2;State z=rk4(local,s,mid,q,p);
            if(!valid(z,p)||gap(z,q,p)>=p.delta)hi=mid;else lo=mid;
          }
          s=rk4(local,s,hi,q,p);local+=hi;remaining-=hi;
          if(!valid(s,p)){reason=1;break;}
          if(!jump(local,s)||++internal>200){reason=5;break;}
        }else{s=end;local+=trial;remaining-=trial;}
      }
      if(reason){t=local;path+=std::hypot(s.x-before.x,s.y-before.y)*p.L;break;}
    }else if(p.plant==2){
      s=held(s,u,turn,h);vactual=u;wactual=turn;clipv=clipa=0;
    }else{
      double vp=u*p.L/p.T,wp=turn/p.T,dt=h*p.T;
      double left=(vp-.5*p.track*wp)/p.wheel_radius,right=(vp+.5*p.track*wp)/p.wheel_radius;
      double tl=std::clamp(left,-p.wheel_cap,p.wheel_cap),tr=std::clamp(right,-p.wheel_cap,p.wheel_cap);
      clipv=(std::abs(left)>p.wheel_cap+1e-12||std::abs(right)>p.wheel_cap+1e-12)?1:0;
      double al=(tl-s.wl)/p.wheel_tau,ar=(tr-s.wr)/p.wheel_tau;
      clipa=(std::abs(al)>p.acc_cap+1e-12||std::abs(ar)>p.acc_cap+1e-12)?1:0;
      al=std::clamp(al,-p.acc_cap,p.acc_cap);ar=std::clamp(ar,-p.acc_cap,p.acc_cap);
      double nl=s.wl+dt*al,nr=s.wr+dt*ar;
      double vm=.25*p.wheel_radius*(s.wl+nl+s.wr+nr),wm=.5*p.wheel_radius*(s.wr+nr-s.wl-nl)/p.track;
      s=held(s,vm*p.T/p.L,wm*p.T,h);s.wl=nl;s.wr=nr;
      vactual=.5*p.wheel_radius*(nl+nr)*p.T/p.L;wactual=p.wheel_radius*(nr-nl)/p.track*p.T;
      peakwheel=std::max(peakwheel,std::max(std::abs(nl),std::abs(nr)));
      peakacc=std::max(peakacc,std::max(std::abs(al),std::abs(ar)));
    }
    steps++;t=std::min(steps*p.step,p.horizon);
    path+=std::hypot(s.x-before.x,s.y-before.y)*p.L;
    trackv+=(vactual-u)*(vactual-u)*std::pow(p.L/p.T,2)*h;
    trackw+=(wactual-turn)*(wactual-turn)/(p.T*p.T)*h;
    clipv_time+=clipv*h;clipa_time+=clipa*h;
    if(std::hypot(s.x-p.targetx,s.y-p.targety)*p.L<=.125){dwell+=h;if(dwell*p.T>=8&&firstdwell<0)firstdwell=t*p.T;}else dwell=0;
    if(steps>200000000){reason=4;break;}
  }
  if(p.geometry&&std::isfinite(s.x)&&std::isfinite(s.y)){
    minchart=std::min(minchart,std::hypot(s.x-p.obstacle_x,s.y-p.obstacle_y)-p.dstar);
    minphysical=std::min(minphysical,std::hypot(s.x-p.obstacle_x,s.y-p.obstacle_y)*p.L-p.physical_exclusion);
  }
  // A guard may stop before the normal save boundary. Keep the actual terminal state.
  if(rows<capacity&&(rows==0||trace[(rows-1)*NC]<t-1e-12)){save(trace+rows*NC);rows++;}
  metrics[0]=reason;metrics[1]=t;metrics[2]=minchart;metrics[3]=minphysical;metrics[4]=path;
  metrics[5]=std::sqrt(trackv/std::max(t,1e-30));metrics[6]=std::sqrt(trackw/std::max(t,1e-30));
  metrics[7]=clipv_time/std::max(t,1e-30);metrics[8]=clipa_time/std::max(t,1e-30);
  metrics[9]=std::hypot(s.x-p.targetx,s.y-p.targety)*p.L;metrics[10]=dwell*p.T;metrics[11]=firstdwell;
  metrics[12]=nev;metrics[13]=peakwheel;metrics[14]=peakacc;metrics[15]=peakjumpresid;
  metrics[16]=detail_rows;metrics[17]=steps;metrics[18]=rejected_x;metrics[19]=rejected_y;metrics[20]=rejected_time;metrics[21]=adaptive_halvings;metrics[22]=initial_recoveries;metrics[23]=std::sqrt(err_integral/std::max(err_duration,1e-30));metrics[24]=err_max;metrics[25]=err_duration;return rows;
}
