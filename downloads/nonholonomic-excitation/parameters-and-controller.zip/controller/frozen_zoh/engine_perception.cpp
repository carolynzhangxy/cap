#include "frozen/engine_guard.cpp"
// The included reference is byte-for-byte frozen. This new interface replaces
// ONLY geometry evaluation by the delivered ZOH position. Source loss is a
// separate environment sensor at the actual RK stage position.
struct LoopState {
 double t,x,y,path,min_safe,min_d,max_error,dwell,first_dwell,steps,max_step_error;
 int q,reason;
};
static XY perceived_flow(double t,double x,double y,double B,const Params& p) {
 double scalar_sensor_minus_J=environment_loss(x,y,p);
 double u=command(t,scalar_sensor_minus_J+B,p);
 double a=p.heading0+2*PI*std::sqrt(p.omega)*t;
 return {u*std::cos(a),u*std::sin(a)};
}
static XY perceived_rk(double t,XY s,double h,double B,const Params& p) {
 XY a=perceived_flow(t,s.x,s.y,B,p);
 XY b=perceived_flow(t+h/2,s.x+h*a.x/2,s.y+h*a.y/2,B,p);
 XY c=perceived_flow(t+h/2,s.x+h*b.x/2,s.y+h*b.y/2,B,p);
 XY d=perceived_flow(t+h,s.x+h*c.x,s.y+h*c.y,B,p);
 return {s.x+h*(a.x+2*b.x+2*c.x+d.x)/6,s.y+h*(a.y+2*b.y+2*c.y+d.y)/6};
}
static int observed_domain(XY z,int q,const Params& p) {
 if(!std::isfinite(z.x)||!std::isfinite(z.y))return 7;
 double r=std::hypot(z.x-p.obstacle_x,z.y-p.obstacle_y);
 if(r*p.L<=p.physical_exclusion)return 1;
 if(r<=p.safe_radius)return 2;
 if(cover_distance(z.x,z.y,q,p)<=0)return 3;
 if(r<=p.dstar)return 5;
 return 0;
}
extern "C" double geometry_distance(const Params* p,double x,double y,int q){return cover_distance(x,y,q,*p);}
extern "C" double geometry_barrier(const Params* p,double d){return cover_barrier(d,*p);}
extern "C" double geometry_gap(const Params* p,double x,double y,int q){return gap(State{x,y,0},q,*p);}
extern "C" double sensor_minus_J(const Params* p,double x,double y){return environment_loss(x,y,*p);}
extern "C" int advance_perception(const Params* pp,LoopState* sp,double until,double hx,double hy,int verify) {
 const Params& p=*pp;LoopState& s=*sp;
 double B=cover_barrier(cover_distance(hx,hy,s.q,p),p);
 if(!std::isfinite(B)){s.reason=4;return 4;}
 while(s.t<until-1e-14) {
  double h=std::min(p.step,until-s.t);XY before{s.x,s.y};
  XY mid=perceived_rk(s.t,before,h/2,B,p),end=perceived_rk(s.t,before,h,B,p);
  if(verify){XY fine=perceived_rk(s.t+h/2,mid,h/2,B,p);s.max_step_error=std::max(s.max_step_error,std::hypot(fine.x-end.x,fine.y-end.y));}
  int why=observed_domain(mid,s.q,p);bool middle_bad=why!=0;
  if(!why)why=observed_domain(end,s.q,p);
  if(why && why!=7){
   double lo=0,hi=middle_bad?h/2:h;
   for(int k=0;k<45;k++){double v=(lo+hi)/2;XY z=perceived_rk(s.t,before,v,B,p);if(observed_domain(z,s.q,p))hi=v;else lo=v;}
   h=hi;end=perceived_rk(s.t,before,h,B,p);mid=perceived_rk(s.t,before,h/2,B,p);
  }
  s.path+=std::hypot(end.x-s.x,end.y-s.y)*p.L;s.x=end.x;s.y=end.y;s.t+=h;s.steps++;
  for(XY z:{mid,end}){
   s.min_safe=std::min(s.min_safe,(std::hypot(z.x-p.obstacle_x,z.y-p.obstacle_y)-p.safe_radius)*p.L);
   s.min_d=std::min(s.min_d,cover_distance(z.x,z.y,s.q,p)*p.L);
   s.max_error=std::max(s.max_error,std::hypot(z.x-hx,z.y-hy)*p.L);
  }
  if(std::hypot(s.x-p.targetx,s.y-p.targety)*p.L<=.125)s.dwell+=h*p.T;else s.dwell=0;
  if(s.dwell>=8 && s.first_dwell<0)s.first_dwell=s.t*p.T;
  if(why){s.reason=why;return why;}
 }
 return 0;
}
