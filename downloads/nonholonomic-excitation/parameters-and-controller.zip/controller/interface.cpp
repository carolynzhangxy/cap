#include "frozen_zoh/engine_perception.cpp"
#include <vector>
#include <deque>
#include <random>
#include <cstring>
#include <array>

// All lengths internal to the controller are in world units. Source access is
// confined to the environment sensor in deriv(). The odometry states ox,oy
// receive applied-input quadrature, never differences of true positions.
struct Options {double epsilon,heading_bias,yaw_bias,speed_bias,trace_period;int method;};
struct Pair {double x,y,hx,hy,ox,oy;};
struct Derivative {double x,y,hx,hy,u;};
constexpr int NTRACE=24;
struct Interface {
 Params p;Options o;Pair z;double t=0,eps=0,path=0,dwell=0,first_dwell=-1;
 double max_error=0,min_true=INFINITY,min_rob=INFINITY,min_cover=INFINITY,min_safe=INFINITY;
 double max_consistency=0,max_local=0,next_trace=0,last_correction=0;
 long long steps=0;int q,reason=0,switches=0,empty_events=0,bound_violations=0;
 double first_bound_violation=-1,min_interjump=INFINITY,last_jump=-1;
 std::vector<double> trace,events;std::deque<std::array<double,8>> history;
 Interface(const Params& a,const Options& b):p(a),o(b),z{a.initial_x,a.initial_y,a.initial_x,a.initial_y,0,0},eps(b.epsilon),q(a.initial_mode){}
 double d(const Pair& s,int k,bool truth=false)const{return std::hypot((truth?s.x:s.hx)-p.obstacle_x,(truth?s.y:s.hy)-p.obstacle_y)-p.dstar;}
 double margin(const Pair& s,int k)const{return d(s,k)-(o.method==2?eps:0);}
 double cost(const Pair& s,int k)const{return barrier(d(s,k),p)+mode_term(s.hx,s.hy,k,p);}
 double gap_at(const Pair& s)const {
  double a=cost(s,q),b=cost(s,3-q);
  if(!std::isfinite(a))return std::isfinite(b)?INFINITY:NAN;
  return a-std::min(a,b);
 }
 int state_reason(const Pair& s)const {
  if(!std::isfinite(s.x)||!std::isfinite(s.y)||!std::isfinite(s.hx)||!std::isfinite(s.hy))return 7;
  double r=std::hypot(s.x-p.obstacle_x,s.y-p.obstacle_y);
  if(r*p.L<=p.physical_exclusion)return 5;
  if(r<=p.safe_radius)return 4;
  if(d(s,q,true)<=0)return 1;
  if(r<=p.dstar)return 1; // explicitly log map margin in all records
  if(o.method==2&&std::max(d(s,1),d(s,2))<=eps)return 3;
  if(margin(s,q)<=0)return 2;
  return 0;
 }
 Derivative deriv(double tt,const Pair& s)const {
  Pair truth=s;truth.hx=s.x;truth.hy=s.y;
  double b=cost(o.method==3?truth:s,q);
  if(!std::isfinite(b))return {NAN,NAN,NAN,NAN,NAN};
  double measured_minus_J=environment_loss(s.x,s.y,p);
  double applied_u1=command(tt,measured_minus_J+b,p);
  double theta=p.heading0+2*PI*std::sqrt(p.omega)*tt;
  double heading_est=theta+o.heading_bias+o.yaw_bias*tt*p.T;
  return {applied_u1*std::cos(theta),applied_u1*std::sin(theta),
   applied_u1*(1+o.speed_bias)*std::cos(heading_est),applied_u1*(1+o.speed_bias)*std::sin(heading_est),applied_u1};
 }
 static Pair add(const Pair& s,const Derivative& a,double h){return {s.x+h*a.x,s.y+h*a.y,s.hx+h*a.hx,s.hy+h*a.hy,s.ox+h*a.hx,s.oy+h*a.hy};}
 Pair rk(double tt,const Pair& s,double h,std::array<double,8>* hist=nullptr)const {
  if(o.method==0){
   XY end=perceived_rk(tt,{s.x,s.y},h,cost(s,q),p);
   return {end.x,end.y,s.hx,s.hy,s.ox,s.oy};
  }
  Derivative a=deriv(tt,s),b=deriv(tt+h/2,add(s,a,h/2)),c=deriv(tt+h/2,add(s,b,h/2)),v=deriv(tt+h,add(s,c,h));
  Derivative m{(a.x+2*b.x+2*c.x+v.x)/6,(a.y+2*b.y+2*c.y+v.y)/6,
   (a.hx+2*b.hx+2*c.hx+v.hx)/6,(a.hy+2*b.hy+2*c.hy+v.hy)/6,0};
  if(hist)*hist={tt*p.T,h*p.T,a.u,b.u,c.u,v.u,h*m.hx,h*m.hy};
  return add(s,m,h);
 }
 void monitor(const Pair& s){
  double e=std::hypot(s.x-s.hx,s.y-s.hy);max_error=std::max(max_error,e*p.L);
  min_true=std::min(min_true,d(s,q,true)*p.L);min_rob=std::min(min_rob,(d(s,q)-eps)*p.L);
  min_cover=std::min(min_cover,(std::max(d(s,1),d(s,2))-eps)*p.L);
  min_safe=std::min(min_safe,(std::hypot(s.x-p.obstacle_x,s.y-p.obstacle_y)-p.safe_radius)*p.L);
  if(e>eps+1e-10){bound_violations++;if(first_bound_violation<0)first_bound_violation=t*p.T;}
 }
 void save(){
  double dt1=d(z,1,true)*p.L,dt2=d(z,2,true)*p.L,dh1=d(z,1)*p.L,dh2=d(z,2)*p.L;
  Pair truth=z;truth.hx=z.x;truth.hy=z.y;double bt=cost(truth,q),btother=cost(truth,3-q);
  double gtrue=std::isfinite(bt)?bt-std::min(bt,btother):std::isfinite(btother)?INFINITY:NAN;
  double bp=cost(z,q),bo=cost(z,3-q);
  double gp=std::isfinite(bp)?bp-std::min(bp,bo):std::isfinite(bo)?INFINITY:NAN;
  double row[NTRACE]={t*p.T,z.x,z.y,z.hx,z.hy,(z.x-z.hx)*p.L,(z.y-z.hy)*p.L,eps*p.L,
   dt1,dt2,dh1,dh2,dh1-eps*p.L,dh2-eps*p.L,double(q),gtrue,gp,gap_at(z),
   double((dh1>eps*p.L)+(dh2>eps*p.L)),std::hypot(z.x-z.hx,z.y-z.hy)*p.L,
   (std::hypot(z.x-p.obstacle_x,z.y-p.obstacle_y)-p.safe_radius)*p.L,z.ox,z.oy,dwell};
  trace.insert(trace.end(),row,row+NTRACE);
 }
 bool supervise(){
  double a=cost(z,q),b=cost(z,3-q);
  if(!std::isfinite(a)&&!std::isfinite(b)){reason=o.method==2?3:2;if(reason==3)empty_events++;return false;}
  if(p.switch_enabled&&(!std::isfinite(a)||a-std::min(a,b)>=p.delta)){
   int old=q;q=a<=b?old:3-old;
   if(q==old){reason=7;return false;}
   if(last_jump>=0)min_interjump=std::min(min_interjump,(t-last_jump)*p.T);
   last_jump=t;switches++;
   double ev[]={t*p.T,double(old),double(q),a,b,z.x,z.y,z.hx,z.hy,eps*p.L};
   events.insert(events.end(),ev,ev+10);
  }
  reason=state_reason(z);if(reason==3)empty_events++;return !reason;
 }
 void correction(double hx,double hy,double ox_capture,double oy_capture,double epsilon){
  if(reason)return;
  // odometry history was integrated from actual causally applied inputs.
  z.hx=hx+(o.method==0?0:z.ox-ox_capture);z.hy=hy+(o.method==0?0:z.oy-oy_capture);eps=epsilon;last_correction=t;
  if(o.method==0){ // preserve the audited old release-order semantics
   if(d(z,q)<=0){reason=2;return;}
  }
  supervise();monitor(z);
  if(t*p.T>=next_trace-1e-10||reason){save();next_trace=t*p.T+o.trace_period;}
 }
 void advance(double until){
  while(t<until-1e-14&&!reason){
   if(o.method!=0&&!supervise())break;
   int initial_bad=state_reason(z);if(initial_bad){reason=initial_bad;break;}
   double h=std::min(p.step,until-t);Pair start=z,mid{},end{};int cuts=0;
   while(true){
    mid=rk(t,start,h/2);end=rk(t,start,h);
    bool finite=std::isfinite(end.x)&&std::isfinite(end.hx)&&std::isfinite(mid.x)&&std::isfinite(mid.hx);
    bool accurate=true;
    if(o.method!=0&&finite&&p.adaptive_check&&margin(start,q)<.08){
     Pair fine=rk(t+h/2,mid,h/2);
     double localerr=std::hypot(fine.x-end.x,fine.y-end.y);
     accurate=std::isfinite(localerr)&&localerr<=p.solver_tol*(1+std::hypot(start.x-p.obstacle_x,start.y-p.obstacle_y));
    }
    if(o.method==0||(finite&&accurate))break;
    if(cuts++>=35||h<1e-13){reason=7;break;}h/=2;
   }
   if(reason)break;
   bool jump=p.switch_enabled&&o.method!=0&&(gap_at(mid)>=p.delta||gap_at(end)>=p.delta);
   int badmid=state_reason(mid),badend=state_reason(end);
   if(jump||badmid||badend){
    double lo=0,hi=(badmid||(p.switch_enabled&&o.method!=0&&gap_at(mid)>=p.delta))?h/2:h;
    for(int k=0;k<45;k++){
     double v=(lo+hi)/2;Pair at=rk(t,start,v);
     if(state_reason(at)||(p.switch_enabled&&o.method!=0&&gap_at(at)>=p.delta))hi=v;else lo=v;
    }
    h=hi;mid=rk(t,start,h/2);end=rk(t,start,h);
   }
   if(o.method!=0){
    std::array<double,8> hist;end=rk(t,start,h,&hist);history.push_back(hist);
    while(!history.empty()&&history.front()[0]<(t*p.T-.2))history.pop_front();
   }
   path+=std::hypot(end.x-z.x,end.y-z.y)*p.L;z=end;t+=h;steps++;
   monitor(mid);monitor(end);
   if(std::hypot(start.x-p.targetx,start.y-p.targety)*p.L<=.125 && std::hypot(mid.x-p.targetx,mid.y-p.targety)*p.L<=.125 && std::hypot(z.x-p.targetx,z.y-p.targety)*p.L<=.125)dwell+=h*p.T;else dwell=0;
   if(dwell>=8&&first_dwell<0)first_dwell=t*p.T;
   int why=state_reason(z);
   if(why){
    // A finite alternative may be selected by the unchanged continuous guard.
    if(why==2&&o.method!=0&&std::isfinite(cost(z,3-q)))supervise();
    else {reason=why;if(why==3)empty_events++;}
   }else if(p.switch_enabled&&o.method!=0&&gap_at(z)>=p.delta)supervise();
   if(t*p.T>=next_trace-1e-10||reason){save();next_trace=t*p.T+o.trace_period;}
   if(steps>200000000){reason=7;break;}
  }
 }
};
extern "C" void* interface_create(const Params* p,const Options* o){return new Interface(*p,*o);}
extern "C" void interface_delete(void* h){delete (Interface*)h;}
extern "C" int interface_advance(void* h,double t){auto& a=*(Interface*)h;a.advance(t);return a.reason;}
extern "C" int interface_correct(void* h,double x,double y,double ox,double oy,double ep){auto& a=*(Interface*)h;a.correction(x,y,ox,oy,ep);return a.reason;}
extern "C" void interface_snapshot(void* h,double* b){auto& a=*(Interface*)h;double row[]={a.t,a.z.x,a.z.y,a.z.hx,a.z.hy,a.z.ox,a.z.oy,double(a.q),double(a.reason),a.eps};std::copy(row,row+10,b);}
extern "C" int interface_trace(void* h,double* b){auto& a=*(Interface*)h;if(b)std::copy(a.trace.begin(),a.trace.end(),b);return a.trace.size()/NTRACE;}
extern "C" int interface_events(void* h,double* b){auto& a=*(Interface*)h;if(b)std::copy(a.events.begin(),a.events.end(),b);return a.events.size()/10;}
extern "C" void interface_finish(void* h,double* b){
 auto& a=*(Interface*)h;a.monitor(a.z);a.save();
 double row[]={double(a.reason),a.t*a.p.T,a.path,a.dwell,a.first_dwell,a.max_error,a.min_true,a.min_rob,a.min_cover,a.min_safe,double(a.steps),double(a.switches),double(a.empty_events),double(a.bound_violations),a.first_bound_violation,a.min_interjump};std::copy(row,row+16,b);
}
struct Synthetic {double period,latency,amplitude,horizon;int kind,seed;};
extern "C" void interface_synthetic(void* ptr,const Synthetic* s){
 auto& a=*(Interface*)ptr;
 struct Packet {double release,x,y,ox,oy;};std::deque<Packet> queue;
 std::mt19937_64 rng(s->seed);std::uniform_real_distribution<double> uniform(0,1);
 int tick=0;double capture=0;
 while(a.t*a.p.T<std::abs(s->horizon)-1e-8&&!a.reason){
  double now=a.t*a.p.T;
  if(capture<=now+1e-8){
   double vx=0,vy=0;
   if(s->kind==1||s->kind==6){vx=1;}
   if(s->kind==2){vx=std::cos(.1*capture);vy=std::sin(.1*capture);}
   if(s->kind==3){double angle=2*PI*uniform(rng),r=std::sqrt(uniform(rng));vx=r*std::cos(angle);vy=r*std::sin(angle);}
   if(s->kind==4){double r=std::hypot(a.z.x-a.p.obstacle_x,a.z.y-a.p.obstacle_y);vx=-(a.z.x-a.p.obstacle_x)/r;vy=-(a.z.y-a.p.obstacle_y)/r;}
   if(s->kind==5){vx=a.p.obstacle_x-a.z.x;vy=a.p.obstacle_y-a.z.y;double n=std::hypot(vx,vy);vx/=n;vy/=n;}
   double amp=s->amplitude/a.p.L;
   if(!(s->kind==6&&tick%100>=30&&tick%100<35))
    queue.push_back({capture+s->latency,a.z.x+amp*vx,a.z.y+amp*vy,a.z.ox,a.z.oy});
   capture=(++tick)*s->period;
  }
  while(!queue.empty()&&queue.front().release<=now+1e-8&&!a.reason){
   auto v=queue.front();queue.pop_front();a.correction(v.x,v.y,v.ox,v.oy,a.o.epsilon);
  }
  if(a.reason || (s->horizon>0 && a.dwell>=8-1e-8))break;
  double next=std::min(std::abs(s->horizon),std::min(capture,queue.empty()?std::abs(s->horizon):queue.front().release));
  if(next<=now+1e-10){a.reason=7;break;}a.advance(next/a.p.T);
 }
}

extern "C" double demo_dwell(void* h){return ((Interface*)h)->dwell;}
