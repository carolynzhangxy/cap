HOLONOMIC AMPLITUDE COMPARISON AT OMEGA = 60 RAD/S

The four runs use a=0.12,0.16,0.20,0.24. Only a changes from the selected
omega=60 frequency-comparison run. The a=0.16 trajectory is reproduced exactly.
All other coefficients, initial oscillator phase and mode, geometry, integration
settings and arrival condition are frozen. Changing a changes both a*omega and
2*k/a; it is not just a geometric scaling of a previously computed trajectory.

This is a new exact-position numerical illustration, not a learned-perception
record. The robot body has a fixed orientation. Mode q=2 throughout these runs.
Each video is 76 s at 1920x1080/30 fps: an initial hold of 1.5 s, model horizon
9 s at common 0.125x playback, and a final 2.5 s hold. Each run stops at the
first integration sample in the radius-0.35 source neighborhood.

All full scenes use [-5.5,5.5] on both axes. At each model time, the four local
insets share one width chosen to contain their recent two cycles, with equal
x/y scale. This common width is displayed; each inset centers on its own path.

JSON/CSV contain full-precision model time, x,y,q and source distance. JSON also
includes coefficients, reference provenance and step-halving verification.
To regenerate: node scripts/generate_holonomic_amplitudes.mjs
The required reference dataset and controller source are included at their
original relative paths. The controller SHA-256 is recorded in runs.json.
