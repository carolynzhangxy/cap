import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {simulate} from '../dist/static/js/scene-controller.js';

// Preserve the author's selected omega=60 run, including oscillator phase.
const previous=JSON.parse(fs.readFileSync(new URL('../dist/data/holonomic-frequency-comparison/runs.json',import.meta.url)));
const reference=previous.runs.find(r=>r.config.omega===60),layout=previous.layout,runs=[];
assert.ok(reference);
for(const a of [.12,.16,.20,.24]){
 const options={...reference.config,a};
 const run=simulate(layout,options),fine=simulate(layout,{...options,step:options.step/2});
 assert.equal(run.reason,'arrived');assert.ok(run.minClearance>0);
 const rows=[];for(let i=0;i<run.points.length;i+=5)rows.push(Array.from(run.points.slice(i,i+5)));
 const fineRows=[];for(let i=0;i<fine.points.length;i+=5)fineRows.push(Array.from(fine.points.slice(i,i+5)));
 let j=0,error=0,matched=0;
 for(const p of rows){while(j+1<fineRows.length&&fineRows[j+1][0]<=p[0]+1e-10)j++;
  if(Math.abs(fineRows[j][0]-p[0])<1e-10){error=Math.max(error,Math.hypot(p[1]-fineRows[j][1],p[2]-fineRows[j][2]));matched++;}}
 assert.ok(error<.002,`Step-halving discrepancy: ${error}`);
 assert.deepEqual(run.events,fine.events);
 const bounds=[Math.min(...rows.map(r=>r[1])),Math.max(...rows.map(r=>r[1])),Math.min(...rows.map(r=>r[2])),Math.max(...rows.map(r=>r[2]))];
 assert.ok(bounds.every(v=>Math.abs(v)<5.15));
 if(a===.16){assert.deepEqual(rows,reference.rows);assert.equal(run.arrival,reference.arrival);assert.equal(run.minClearance,reference.minClearance);}
 // At fixed omega, a changes BOTH coefficients of the original input law.
 runs.push({...run,points:undefined,rows,oscillatorCyclesPerSecond:60/(2*Math.PI),
  coefficients:{aOmega:a*60,twoKOverA:2*options.k/a},
  verification:{halfStepMaxPositionError:error,matchedSamples:matched,arrivalTimeDifference:Math.abs(run.arrival-fine.arrival),bounds,referenceReproduced:a===.16}});
}
for(const key of Object.keys(reference.config).filter(k=>k!=='a'))for(const run of runs)assert.deepEqual(run.config[key],reference.config[key],`Only a may change: ${key}`);
const horizon=Math.ceil(Math.max(...runs.map(r=>r.duration))*2)/2;
const out={scope:'New exact-position holonomic amplitude comparison at the author-selected omega=60 rad/s; not learned-perception experimental records.',
 layout,columns:previous.columns,reference:{omega:60,a:.16,source:'holonomic-frequency-comparison/runs.json',trajectoryReproducedExactly:true},
 video:{...previous.video,horizon,duration:previous.video.intro+horizon/previous.video.speed+previous.video.outro,
  detail:'Recent two oscillator cycles. Shared x/y display scale across every run at the same model time; the common view width is displayed.'},
 controllerSha256:crypto.createHash('sha256').update(fs.readFileSync(new URL('../dist/static/js/scene-controller.js',import.meta.url))).digest('hex'),runs};
const dir=new URL('../dist/data/holonomic-amplitude-comparison/',import.meta.url);fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(new URL('runs.json',dir),JSON.stringify(out));
console.log(JSON.stringify({video:out.video,runs:runs.map(r=>({a:r.config.a,arrival:r.arrival,minClearance:r.minClearance,coefficients:r.coefficients,verification:r.verification}))},null,2));
