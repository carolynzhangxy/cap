These files reproduce the updated visual replay; no experiments were rerun.
S0 v7: synchronized variable-speed playback; see provenance.json playback_segments and local_detail. The 80x view is a crop, not altered coordinates.
Original trajectory CSV: 0.2 s saved trace plus terminal sample.
Perception NPZ: lossless selected columns of the original 0.02 s capture-time record.
Use capture_s, true_x/y, estimate_x/y for paths; release_s records estimate availability.
Lengths in NPZ are workspace units (multiply by L=0.5 for meters). Times are seconds (tau=t/T, T=80).
frames.q is the PRE-CORRECTION routing mode; use initial_mode plus events to recover displayed post-jump q.
Heading = heading0 + 2*pi*sqrt(omega)*capture_s/T. Terminal pose is from the final trace, held after completion.
Full-frame usage = cumsum(expert==1) / count. Startup pre-jump hold precedes the first displayed update.
The renderer consumes every 0.02 s saved position, not a new high-rate integration.
The paper rounds the recorded 0.125 m arrival neighborhood to 0.13 m; the 8 s dwell is preserved.
