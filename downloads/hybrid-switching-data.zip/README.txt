HOLONOMIC HYBRID SWITCHING — TWO-ROUTE ILLUSTRATION

New exact-position numerical simulations of the manuscript holonomic oscillatory controller. This is not a learned-perception experiment.
Run A: initial position (-0.3, -2.4), q(0)=1; remains in mode 1 and passes left.
Run B: initial position (0.3, -2.4), q(0)=1; switches 1 -> 2 at model time 0.25185 s and passes right.
Both: source (0, 2.4), obstacle (0, 0), a=0.16, k=1.4, omega=800 rad/s, initial oscillator phase 0, delta=0.15, covering radius 0.92. Stop at first entry into the radius-0.35 source neighborhood.
The q labels are mode/potential indices, not universal directions.

runs.json contains all sampled positions, event positions, pre/post modes, potential values, settings and step-halving checks. The integration step is 0.000025 s; regular output is at 0.0005 s, plus the exact discrete integration step that triggers the jump and first arrival. No state projection or fitted path is used. Position and oscillator are unchanged across a jump.
Run reproduce.mjs with a current Node.js version to verify the saved trajectories against the included controller snapshot; no package installation is needed.

The video has an introductory hold, a full Run A, a slower approach to the Run B event, pre/post event holds, Run B continuation, and a synchronized comparison. The video timestamps and model time are different. Chapter times: 0, 3, 23, 30, 34, 51 seconds. Total video duration: 66 seconds, 1920x1080, 30 fps. The trail retains every logged position; the inset shows the last two dither cycles.
