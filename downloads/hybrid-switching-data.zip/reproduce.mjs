import fs from 'node:fs';
import assert from 'node:assert/strict';
import {simulate} from './scene-controller.mjs';
const data=JSON.parse(fs.readFileSync(new URL('./runs.json',import.meta.url)));
for(const saved of data.runs){const actual=simulate(saved.layout,saved.config);assert.deepEqual([...actual.points],saved.rows.flat());assert.deepEqual(actual.jumpStates,saved.jumpStates);console.log(saved.id,actual.reason,actual.arrival,actual.events);}
